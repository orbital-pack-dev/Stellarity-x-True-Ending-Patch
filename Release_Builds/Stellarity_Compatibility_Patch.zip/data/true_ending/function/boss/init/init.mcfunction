# инициализация параметров босса
particle dragon_breath ~ ~ ~ 0 0 0 1 140 force @a[distance=..256]
particle dragon_breath ~ ~ ~ 0 0 0 2 140 force @a[distance=..256]
item replace entity @s weapon.mainhand with totem_of_undying
tag @s remove trueEnding_inattack
scoreboard players reset @s trueEnding_health_extra
scoreboard players reset @s trueEnding_health_extra_max
execute store result entity @s attributes[{id:"minecraft:max_health"}].base double 1 run scoreboard players get dragonhealth trueEnding_settings

# шкала при среднем здоровье
execute store result entity @s Health float 1 run scoreboard players get dragonhealth trueEnding_settings

# шкала при высоком здоровье
execute if score dragonhealth trueEnding_settings matches 1025..2048 run function true_ending:boss/init/1024_2048_make_bossbars_proportionate

# сохранение максимального здоровья
execute if score dragonhealth trueEnding_settings matches 2049.. run function true_ending:boss/init/2048_above
execute store result score @s trueEnding_health_max run data get entity @s attributes[{id:"minecraft:max_health"}].base

# совместимость со сбросом
execute store result score @s trueEnding_health_extra_max run scoreboard players get @s trueEnding_health_extra
scoreboard objectives add refresh_maxhealth dummy
execute store result score @s refresh_maxhealth run scoreboard players get dragonhealth trueEnding_settings
tag @s add refresh_entity_exists
execute if score @s trueEnding_health_max matches 1025.. run scoreboard players set @s trueEnding_health_max 1024
attribute @s knockback_resistance base set 300
kill @e[type=marker,tag=trueEnding_endspike]
kill @e[type=phantom,tag=trueEnding_guardphantom]
execute positioned 63 125 0 run function true_ending:boss/phantom/summon_marker
execute positioned 50 125 36 run function true_ending:boss/phantom/summon_marker
execute positioned 18 125 59 run function true_ending:boss/phantom/summon_marker
execute positioned -19 125 59 run function true_ending:boss/phantom/summon_marker
execute positioned -51 125 36 run function true_ending:boss/phantom/summon_marker
execute positioned -63 125 0 run function true_ending:boss/phantom/summon_marker
execute positioned -51 125 -39 run function true_ending:boss/phantom/summon_marker
execute positioned -19 125 -60 run function true_ending:boss/phantom/summon_marker
execute positioned 18 125 -60 run function true_ending:boss/phantom/summon_marker
execute positioned 50 125 -39 run function true_ending:boss/phantom/summon_marker
scoreboard players set @s trueEnding_bosstime 218
tag @s add trueEnding_dragon_particlechecked
