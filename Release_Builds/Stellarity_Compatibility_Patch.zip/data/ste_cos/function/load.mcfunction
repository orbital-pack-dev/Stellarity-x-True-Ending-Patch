# =====================================================================
# ste_cos:load
# Compatibility & Cosmetic Patch — initialization.
# =====================================================================

# TODO: ste_settings:init

# Лимит блоков
gamerule max_block_modifications 1999999999

# Объектив флагов
scoreboard objectives add ste_cos.flags dummy '{"text":"STE-COS Flags"}'

# Таймер уборки хоруса
scoreboard players set $pull_timer ste_cos.flags 0

# Фикс портала
execute unless score #portal_fix_done ste_cos.flags matches 1 run scoreboard players set #portal_fix_done ste_cos.flags 0
execute unless score #portal_fix ste_cos.timer matches 1.. run scoreboard players set #portal_fix ste_cos.timer 0

# ID стражей
scoreboard objectives add ste_cos.id dummy '{"text":"STE-COS IDs"}'

# Таймер
scoreboard objectives add ste_cos.timer dummy '{"text":"STE-COS Timer"}'

# Поиск яйца
scoreboard objectives add ste_cos.search_stage dummy '{"text":"STE-COS Search Stage"}'

# Радиус орбиты
scoreboard objectives add ste_cos.radius dummy '{"text":"STE-COS Orbit Radius"}'

# Высота орбиты
scoreboard objectives add ste_cos.orbit_y dummy '{"text":"STE-COS Orbit Y"}'

# RNG тикер
scoreboard players set #rng_ticker ste_cos.flags 0 

# Форслоад чанка
execute unless score #forceloaded ste_cos.flags matches 1.. run execute in minecraft:the_end run forceload add -112 -112 112 112
execute unless score #forceloaded ste_cos.flags matches 1.. run scoreboard players set #forceloaded ste_cos.flags 1
