# ste_cos:portal/check_item
# проверка дропа портала

tag @s add ste_cos_item_checked

# Дроп яйца дракона
execute if data entity @s Item{id:"minecraft:dragon_egg"} run kill @s

# Дроп факелов
execute if data entity @s Item{id:"minecraft:torch"} run kill @s
