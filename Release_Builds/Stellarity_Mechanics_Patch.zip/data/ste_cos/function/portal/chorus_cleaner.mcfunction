# =====================================================================
# ste_cos:portal/chorus_cleaner
# Уборка хоруса у портала
# =====================================================================

# Уборка верха
fill -20 66 -20 20 75 20 minecraft:air destroy

# Уборка низа
fill -20 50 -20 20 65 20 minecraft:air replace minecraft:chorus_plant
fill -20 50 -20 20 65 20 minecraft:air replace minecraft:chorus_flower

fill -20 50 -20 20 65 20 minecraft:air replace minecraft:bone_block

