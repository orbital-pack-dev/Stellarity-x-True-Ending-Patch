# =====================================================================
# ste_cos:phantom/guard_move
# Обработка одного стража
# =====================================================================

# Уборка стража
execute unless entity @e[type=end_crystal,distance=..6,limit=1] run function ste_cos:phantom/cleanup_current

# Управление стражем
execute if entity @e[type=end_crystal,distance=..6,limit=1] run function ste_cos:phantom/guard_act
