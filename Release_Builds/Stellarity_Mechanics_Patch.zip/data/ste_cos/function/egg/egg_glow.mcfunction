# ste_cos:egg/egg_glow
# Свечение яйца

# Сброс поиска
scoreboard players set @s ste_cos.search_stage 0

# Добавление таймера
scoreboard players add @s ste_cos.flags 1

# Непрерывные частицы
execute align xyz positioned ~0.5 ~0.05 ~0.5 run function ste_cos:egg/egg_ambient

# Волны и вспышки
execute if score @s ste_cos.flags matches 40 align xyz positioned ~0.5 ~0.05 ~0.5 run function ste_cos:egg/egg_wave
execute if score @s ste_cos.flags matches 40.. run scoreboard players set @s ste_cos.flags 0

# Редкие искры
execute if score @s ste_cos.flags matches 3 align xyz positioned ~0.5 ~0.05 ~0.5 run particle enchant ~ ~ ~ 0 0 0 1 2 force

# Оркестратор пульса
execute if score @s ste_cos.flags matches 0 align xyz positioned ~0.5 ~0.05 ~0.5 run function ste_cos:egg/egg_pulse_trigger

