# =====================================================================
# ste_cos:egg/egg_tick
# Подсветка яйца дракона
# =====================================================================

# Создание маркера
execute in minecraft:the_end unless entity @e[type=marker,tag=ste_cos_egg_tracker] run summon marker 0 66 0 {Tags:["ste_cos_egg_tracker"]}

# Свечение яйца
execute in minecraft:the_end as @e[type=marker,tag=ste_cos_egg_tracker,limit=1] at @s if block ~ ~ ~ minecraft:dragon_egg run function ste_cos:egg/egg_glow

# Поиск яйца
execute in minecraft:the_end as @e[type=marker,tag=ste_cos_egg_tracker,limit=1] at @s unless block ~ ~ ~ minecraft:dragon_egg run function ste_cos:egg/egg_find
