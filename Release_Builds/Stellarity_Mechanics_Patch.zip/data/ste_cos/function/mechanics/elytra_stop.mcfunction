# Поломка элитр
item modify entity @s armor.chest ste_cos:break_elytra

# Звук поломки
playsound minecraft:item.shield.break player @a ~ ~ ~ 1 0.8

# Медленное падение
effect give @s minecraft:slow_falling 3 0 true

# Эффект слабости
effect give @s minecraft:weakness 3 1 true
