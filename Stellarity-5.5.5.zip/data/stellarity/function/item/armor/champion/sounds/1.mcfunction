playsound minecraft:block.anvil.place player @a[distance=0..] ~ ~ ~ 0.5 0.7
playsound minecraft:entity.blaze.hurt player @a[distance=0..] ~ ~ ~ 0.25 0.6
playsound minecraft:entity.warden.attack_impact player @a[distance=0..] ~ ~ ~ 0.7 0.65
