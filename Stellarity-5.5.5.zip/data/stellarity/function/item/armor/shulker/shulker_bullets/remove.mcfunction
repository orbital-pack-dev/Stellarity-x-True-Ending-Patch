kill @s
particle gust
