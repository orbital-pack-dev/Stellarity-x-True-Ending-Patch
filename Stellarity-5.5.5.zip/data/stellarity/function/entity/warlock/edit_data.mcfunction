data merge entity @s {drop_chances:{head:0.0},equipment:{head:{id:"player_head",count:1,components:{custom_name:{"text":"Enderman Evoker","color":"gold","underlined":true,"bold":true,"italic":false},profile:{id:[I;850768264,1579568922,-1452127065,1960687665],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOWE1MTlmNmZjYjU5ZDQwYzdmODg4MDkyOTViMTM5ZmIzMDAyOTVhZDQ1MGVmNmU4YTRlMGYwYWNjYTBkZmJkZCJ9fX0="}]}}}},attributes:[{id:"armor",base:3d},{id:"max_health",base:30d}],Health:30f}

tag @s add stellarity.warlock
