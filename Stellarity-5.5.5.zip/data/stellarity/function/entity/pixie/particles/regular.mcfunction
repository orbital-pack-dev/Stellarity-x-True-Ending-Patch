execute if score @s stellarity.misc3 matches 1 run function stellarity:entity/pixie/particles/idle/yellow
execute if score @s stellarity.misc3 matches 2 run function stellarity:entity/pixie/particles/idle/magenta
execute if score @s stellarity.misc3 matches 3 run function stellarity:entity/pixie/particles/idle/light_blue
execute if score @s stellarity.misc3 matches 4 run function stellarity:entity/pixie/particles/idle/lime
