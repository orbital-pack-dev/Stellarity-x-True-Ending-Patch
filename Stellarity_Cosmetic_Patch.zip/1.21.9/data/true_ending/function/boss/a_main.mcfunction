# след частиц
execute if entity @s[tag=!trueEnding_dragon_particlechecked] run function true_ending:boss/init/init

# счетчики
scoreboard objectives add ste_cos.health dummy
scoreboard objectives add ste_cos.health_old dummy
scoreboard objectives add ste_cos.health_diff dummy
scoreboard objectives add ste_cos.heal_cd dummy

# тотем бессмертия
execute if score #fight_stage ste_cos.stage matches 4.. unless score #ste_cos_totem_used ste_cos.flags matches 1 as @s[tag=!ste_cos.totem_used,tag=!ste_cos.totem_animating] if score @s ste_cos.health matches ..4 run function ste_cos:dragon/trigger_totem
execute if score #fight_stage ste_cos.stage matches 4.. unless score #ste_cos_totem_used ste_cos.flags matches 1 as @s[tag=!ste_cos.totem_used,tag=!ste_cos.totem_animating] if score @s stellarity.dragon.health matches ..4 run function ste_cos:dragon/trigger_totem
execute if score #fight_stage ste_cos.stage matches 4.. unless score #ste_cos_totem_used ste_cos.flags matches 1 as @s[tag=!ste_cos.totem_used,tag=!ste_cos.totem_animating] unless items entity @s weapon.mainhand minecraft:totem_of_undying run function ste_cos:dragon/trigger_totem
execute if score @s ste_cos.heal_cd matches 1.. run scoreboard players remove @s ste_cos.heal_cd 1

# мини-игра клонов
execute if score 20tick trueEnding_clock matches 1 unless score #ste_cos_crystals ste_cos.flags matches 1.. unless score #clone_minigame_used ste_cos.flags matches 1 as @s[tag=!trueEnding_inattack,tag=!ste_cos.minigame_active,tag=!ste_cos.final_breath_active] if score @s ste_cos.health matches 15..280 if predicate true_ending:chance/30_percent run function ste_cos:minigame_clones/check_trigger
execute if score 20tick trueEnding_clock matches 1 unless score #ste_cos_crystals ste_cos.flags matches 1.. unless score #clone_minigame_used ste_cos.flags matches 1 as @s[tag=!trueEnding_inattack,tag=!ste_cos.minigame_active,tag=!ste_cos.final_breath_active] if score @s ste_cos.health matches 15..60 run function ste_cos:minigame_clones/check_trigger

# здоровье
execute store result score @s ste_cos.health run data get entity @s Health 1
execute unless score @s ste_cos.health_old matches 1.. run scoreboard players operation @s ste_cos.health_old = @s ste_cos.health
scoreboard players operation @s ste_cos.health_diff = @s ste_cos.health
scoreboard players operation @s ste_cos.health_diff -= @s ste_cos.health_old
execute if score @s ste_cos.health_diff matches 1.. run function ste_cos:dragon/crystal_heal_check
execute store result score @s ste_cos.health_old run data get entity @s Health 1

# блокировка атак
execute if entity @s[tag=ste_cos.final_stand] run scoreboard players set @s trueEnding_bosstime 0
execute if entity @s[tag=ste_cos.final_stand] run return 0
execute if score #final_breath_used ste_cos.flags matches 1 if score @s ste_cos.health matches ..1 run scoreboard players set @s trueEnding_bosstime 0
execute if score #final_breath_used ste_cos.flags matches 1 if score @s ste_cos.health matches ..1 run return 0
execute if score #final_breath_used ste_cos.flags matches 1 if score @s stellarity.dragon.health matches ..1 run scoreboard players set @s trueEnding_bosstime 0
execute if score #final_breath_used ste_cos.flags matches 1 if score @s stellarity.dragon.health matches ..1 run return 0
execute if entity @s[tag=ste_cos.final_breath_active] run return 0
execute if entity @s[tag=ste_cos.final_breath_ascending] run return 0
execute if entity @s[tag=ste_cos.final_breath_guided] run return 0
execute if entity @s[tag=ste_cos.minigame_active] run return 0

execute if score @s trueEnding_bosstime matches 0.. run scoreboard players add @s trueEnding_bosstime 1
execute store result score @s trueEnding_y run data get entity @s Pos[1]
execute store result score @s trueEnding_dragonphase run data get entity @s DragonPhase
execute if score dragontrail trueEnding_settings matches 1 as @s run particle dust_color_transition{from_color:[1.000,0.000,0.973],scale:3,to_color:[0.000,0.102,1.000]} ~ ~2.5 ~ .6 .6 .6 1 2 force @a[distance=..256]
execute if score dragontrail trueEnding_settings matches 1 as @s run particle dragon_breath ~ ~2.5 ~ .3 .3 .3 .02 2 normal
execute if score @s trueEnding_health_extra matches ..0 run bossbar set true_ending:extra_health players
execute if score 20tick trueEnding_clock matches 1 if score @s trueEnding_health_extra matches 1.. positioned 0 80 0 run bossbar set true_ending:extra_health players @a[distance=..180]
    execute store result score @s trueEnding_health_percent run data get entity @s Health

# фазы
    execute if score @s trueEnding_health_extra matches 1.. run scoreboard players operation @s trueEnding_health_percent += @s trueEnding_health_extra
    execute store result score @s trueEnding_health run scoreboard players get @s trueEnding_health_percent
    scoreboard players set 1000 trueEnding_constants 1000
    scoreboard players operation @s trueEnding_health_percent *= 1000 trueEnding_constants
    scoreboard players set dragonhealth trueEnding_settings 300
    scoreboard players operation @s trueEnding_health_percent /= dragonhealth trueEnding_settings
execute if score music_boss trueEnding_settings matches 1 positioned 0 80 0 as @a[distance=..128] unless score @s trueEnding_music matches 0.. run scoreboard players set @s trueEnding_music 0

# неуязвимость
execute as @s[predicate=true_ending:condition/perching,tag=!trueEnding_inattack] if entity @s[tag=trueEnding_halfhealth] run scoreboard players set @s trueEnding_bosstime 960
execute if score @s[tag=!trueEnding_halfhealth] trueEnding_health_percent matches ..666 run scoreboard players set @s trueEnding_bosstime 1
execute if score @s[tag=!trueEnding_halfhealth] trueEnding_health_percent matches ..666 run tag @s add trueEnding_halfhealth
execute if score @s[tag=!trueEnding_quarterhealth] trueEnding_health_percent matches ..333 run scoreboard players set @s trueEnding_bosstime 2001
execute if score @s[tag=!trueEnding_quarterhealth] trueEnding_health_percent matches ..333 run tag @s add trueEnding_quarterhealth

# атаки и переходы
scoreboard players reset #ste_cos_crystals ste_cos.flags
execute in minecraft:the_end positioned 0 65 0 as @e[type=end_crystal,distance=15..400,tag=!stellarity.respawn_crystal,tag=!ste_cos_portal_fix] run scoreboard players add #ste_cos_crystals ste_cos.flags 1
execute unless score @s[tag=!trueEnding_inattack] trueEnding_bosstime matches 3000.. if score #ste_cos_crystals ste_cos.flags matches 0 run data modify entity @s Invulnerable set value 0b
execute positioned 0 65 0 if loaded ~ ~ ~ if score 5tick trueEnding_clock matches 1 run function true_ending:boss/crystal_count
execute if score 20tick trueEnding_clock matches 1 as @s[tag=!trueEnding_inattack] if predicate true_ending:chance/6_percent run scoreboard players set @s trueEnding_bosstime 1001
execute if score 1min trueEnding_clock matches 1 if entity @p[distance=..128,gamemode=!spectator,gamemode=!creative] if entity @s[tag=!trueEnding_inattack,predicate=!true_ending:condition/dragonphase_perched,tag=trueEnding_halfhealth] if predicate true_ending:chance/20_percent run scoreboard players set @s trueEnding_bosstime 20
execute if score 20tick trueEnding_clock matches 1 unless entity @e[distance=..128,type=area_effect_cloud,tag=trueEnding_dragonbreath_quarter] if score @s[tag=!trueEnding_inattack] trueEnding_health_percent matches ..333 if predicate true_ending:chance/20_percent run scoreboard players set @s trueEnding_bosstime 2001
execute if score @s trueEnding_bosstime matches 0..218 run function true_ending:boss/phase_ultra_fireball
execute if score @s trueEnding_bosstime matches 900..1999 run function true_ending:boss/dive/phase
execute if score @s trueEnding_bosstime matches 2000..2999 run function true_ending:boss/phase_laser
execute if score @s trueEnding_bosstime matches 3000..3999 run function true_ending:boss/phase_totem
execute if score @s trueEnding_bosstime matches 5000..5999 run function true_ending:boss/phase_end_crystals_destroyed
execute if score @s trueEnding_bosstime matches 4001..4100 run function true_ending:boss/phase_extra_ultra
execute if score @s trueEnding_bosstime matches 220 run scoreboard players set @s trueEnding_bosstime 219
